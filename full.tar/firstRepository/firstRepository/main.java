package firstRepository;

import secondRepository.second;

public class main{

    public void myMethod(){

        System.out.println("test3");
    }

    public static void main(String[] args) {
        second newSecond=new second();
        newSecond.myMethod4();

        

    }
    
}

