package thirdRepository;

import java.util.Scanner;
import secondRepository.second;



public class third extends second{


  public   int c=4;

    
    public third(int c) {
        
    this.d=c;  
    
}
    private  Object a=null;
    public int d;
    char value[];
     static int h=0;

    third(Integer e) {
        this.d=e;
        this.c=e;
        
    }
  public  third(){
        
        this.d=34;
        this.c=4;
        h+=1;

    }
    public third(double a){
        super();
    }
    
    
    
    
   


    public static void main(String[] args) {
       second newObj=new second();
        newObj.myMethod(); 
        
        
        
        third newObj2=new third(43);
        newObj2.myMethod("a");
        /*third.a=3;
        third.a="test";*/
        System.out.println("+++++++++++++++++++++++++++++++++++++++==");
        newObj2.myMethod5(101, 1);
        
        
        
        third newObj3=new third(1211);
        newObj3.myMethod5(99, 1);
        

        
        //newObj2.d=5;
        System.out.println(newObj3.d);
        newObj2.myMethod2();

        System.out.println("----------------------------------------");
        third newThird=new third(3.5);
     
        
    }

    public void myMethod(String one){
        
        System.out.println("ala1");
        third newObj3=new third();
       int b=4;
       String c=null;
       a=b;
       a=c;
       

       
    }

    public void myMethod(int three){

        
        System.out.println(a);

      

    
    }
    void myMethod2(){
        System.out.println("podaj a");
        Scanner newScanner=new Scanner(System.in);
        a=newScanner.next();
        int f=2;

        third newObj4=new third();
        newObj4.myMethod3(f);
        
        
        



    }
    void myMethod3(String a){
        System.out.println(a+" String");
    }
    void myMethod3(int a){
        System.out.println(a+2);
    }

    void myMethod5( int c,int d){
        third newO=new third();
        
        c=102;
        System.out.println(g);
        second newSecond=new second();
        third newThird=new third();
        //newSecond.g=24;
        newThird.g=34;
        g=11;
        newO.c=56;
        System.out.println(newO.c);

        System.out.println(newThird.c);
        
        
        
        
        
        System.out.println("-----------------------");
       // System.out.println(third.c);
       //System.out.println(third.c);
       System.out.println(this.c);
        System.out.println(c);
        System.out.println(newO.h);
       
        
    }
    
    
    
    
}