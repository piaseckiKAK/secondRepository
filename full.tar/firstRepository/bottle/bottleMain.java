package bottle;

import java.util.Scanner;


public class bottleMain {

    double capacityOfBottle=10;    
    double spaceLeft;

    public static void main(String[] args) {
           
        Scanner amountOfWaterInput=new Scanner(System.in);
        System.out.println("Give amount of water to input");
        double amountOfWater=amountOfWaterInput.nextDouble();

        bottleMain newObject=new bottleMain();
        newObject.inputMethod(amountOfWater);



        
    }


    void inputMethod(Double inputWater){

        spaceLeft=capacityOfBottle-inputWater;
        System.out.println("space left "+spaceLeft);


    }
}

