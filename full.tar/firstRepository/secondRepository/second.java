package secondRepository;

import thirdRepository.third;

public class second  {
  protected int g=41;
  static int i=0;
   static int j=1;
   static int k=0;
   public int l=1;

    second(){
    i+=1;
    System.out.println("from parent default constructor");
  
  }
  public second(double a){
    System.out.println("double constructor");
  }

    public static void main(String[] args) {
      second newSecond=new second();
      System.out.println(i);
      newSecond.myMethod();
      System.out.println(i);
      newSecond.myMethod3(2);
      
      System.out.println("----------------------------------");
      newSecond.myMethod4();
      System.out.println(newSecond.j);
      
            

      second newSecond2=new second();
      System.out.println(newSecond2.j);
      
      second.myMethod6();
      System.out.println(k+" "+newSecond2.k);
      
    }
  public void myMethod4(){
        System.out.println("from second");
        firstRepository.main newObj=new firstRepository.main();
        newObj.myMethod();

        third newObj2=new third();
        System.out.println(newObj2.c);
        
        j=2;
        System.out.println(j+" j");
        
        
    
    }

    public  void myMethod() {

      second newSecond1=new second();

    System.out.println("ela");
    }
  
    public void myMethod3(Object a) {
      System.out.println("from parent");
      System.out.println();
      this.i=989;
      System.out.println(i);
      
    }

    static void myMethod6(){

       second newSecond3=new second();
       
       k=2;
    }
}
