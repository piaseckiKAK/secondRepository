package secondRepository;

public class second2  {
  private final  int n;
    int o=11;
static{

    
    int m=9;
    //n=45;
    //System.out.println(m+" "+n);
    
    
    
}
    second2(){

       this.n=123;
    }


    second2(double a){
        
        this.n=124;
    }

    second2(String a){
        System.out.println(a);
        n=125;
    }
    public static void main(String[] args) {
        




    new second2();
    //System.out.println(n);
    
    second2 newSecond3=new second2(2.3);
    System.out.println(newSecond3.n+" ten2");
    newSecond3=new second2("k");    
    System.out.println(newSecond3.n+" ten");
    newSecond3=new second2(newSecond3.intValue()+1);


    final second2 newSecond2=new second2("Hello world");
    System.out.println(newSecond2);
    
    }

    void myM(){
        second2 newS2=new second2();
        
        
        
     
    }


    
}
