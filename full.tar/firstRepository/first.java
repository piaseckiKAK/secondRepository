import firstRepository.*;


public class first {

     int a=5;
     public static void main(String[] args) {
          int b=4;
         System.out.println("ala");
         main newMain=new main();
         newMain.myMethod();

         first newFirst=new first();
         newFirst.a=9;      
    }
    void myMethod2(){
         System.out.println("from first");
    }
}    
 
    

